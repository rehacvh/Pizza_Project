import java.sql.SQLException;

public class VeggiePizza implements Pizza {
    Database db = Database.getInstance();
    private String description;
    public VeggiePizza() {
        description = "Veggie Pizza";
    }
    public double getPrice() throws SQLException {
        // Get the cost of the pizza from the database
        return db.getFirstRow("SELECT price FROM pizzas WHERE pizza_name = 'Veggie Pizza'").getDouble("price");
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getIngredients() {
        return null;
    }

}
