import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) throws SQLException {
        System.out.println("Hello world!");
        // Test register function
        Admin user = Admin.getInstance();
        user.login("marwan", "123456");
        if(user.isLoggedIn()){
            System.out.println("User is already logged in");
        }else{
            System.out.println("User is not logged in");
        }
        System.out.println("User role: " + user.getRole());
        System.out.println(user.getPizzasSold());

//         Test view pizza function
//         You can use the viewPizza function to view all pizzas or view pizzas by category
//         To view all pizzas, pass an empty string to the function
//         To view pizzas by category, pass the category name to the function
        HashMap<String,Double> pizzas= user.viewPizzas("Italian Pizza");
        for(String pizza : pizzas.keySet()){
            System.out.println("Name "+pizza+" Price "+pizzas.get(pizza));
        }
//        Order order = new Order();
//        order.setUserId(user.getId());
//        order.setOrderDetails("Pepperoni Pizza");
//        order.setTotalCost(10.0);
//        order.setPaymentMethod("Card");
//        order.setStatus("Pending");
//        order.SaveOrder();
    }
}