import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Order {
    private Integer id;
    private Integer user_id;
    private Integer delivery_id;
    private String order_details;
    private String status;
    private Double total_cost;

    private String payment_method;

    private String order_time;

    private Integer pizzas_count;

    // Getters and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return user_id;
    }

    public void setUserId(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getDeliveryId() {
        return delivery_id;
    }

    public void setDeliveryId(Integer delivery_id) {
        this.delivery_id = delivery_id;
    }

    public String getOrderDetails() {
        return order_details;
    }

    public void setOrderDetails(String order_details) {
        this.order_details = order_details;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getTotalCost() {
        return total_cost;
    }

    public void setTotalCost(Double total_cost) {
        this.total_cost = total_cost;
    }

    public String getOrderTime() {
        return order_time;
    }

    public void setOrderTime(String order_time) {
        this.order_time = order_time;
    }

    public String getPaymentMethod() {
        return payment_method;
    }

    public void setPaymentMethod(String payment_method) {
        this.payment_method = payment_method;
    }

    public Integer getPizzasCount() {
        return pizzas_count;
    }

    public void setPizzasCount(Integer pizzas_count) {
        this.pizzas_count = pizzas_count;
    }

    public void SaveOrder() throws SQLException {
        // Get the database instance
        Database db = Database.getInstance();
        // Get the current date and time
        LocalDateTime now = LocalDateTime.now();
        // Format the date and time
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = now.format(formatter);
        // Insert the order into the database
        db.insertOrUpdate("INSERT INTO orders (user_id, order_details, status, total_cost, payment_method, created_at, pizzas_count) VALUES ('"+ getUserId() +"','"+ getOrderDetails() +"','pending','"+getTotalCost()+"','"+getPaymentMethod()+"','"+formattedDateTime+"', '"+getPizzasCount()+"')");
        if(getPaymentMethod().equals("Card")){
            // Get User's Visa Card id
            Integer cardId = db.getFirstRow("SELECT id FROM cards WHERE user_id = "+getUserId()+" ").getInt("id");
            // Insert a row into the online_payments table
            db.insertOrUpdate("INSERT INTO online_payments (user_id, order_id, card_id, total_payment, status, payment_time) VALUES ('"+ getUserId() +"', LAST_INSERT_ID(), '"+cardId+"', '"+ getTotalCost() +"','Accepted','"+formattedDateTime+"')");
        }
    }

}
