public class PizzaFactory {
    public static Pizza createPizza(String type) {
        Pizza pizza = null;
        if (type.equals("Cheese")) {
            pizza = new CheesePizza();
        } else if (type.equals("Pepperoni")) {
            pizza = new PepperoniPizza();
        } else if (type.equals("Veggie")) {
            pizza = new VeggiePizza();
        } else if (type.equals("Hawaiian")) {
            pizza = new HawaiianPizza();
        } else if (type.equals("Meat Lovers")) {
            pizza = new MeatLoversPizza();
        } else if (type.equals("Margherita")) {
            pizza = new MargheritaPizza();
        }
        return pizza;
    }
}
