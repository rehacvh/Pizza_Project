import java.sql.SQLException;

public class Ranch extends ToppingsDecorator {
    public Ranch(Pizza newPizza) {
        super(newPizza);
        System.out.println("Adding Ranch");
    }
    public String getDescription() {
        return tempPizza.getDescription() + ", Ranch";
    }
    public double getPrice() throws SQLException {
        return tempPizza.getPrice() + .25;
    }
    @Override
    public String getIngredients() {
        return null;
    }

}
