import java.sql.SQLException;

public class FreshTomato extends ToppingsDecorator {
    public FreshTomato(Pizza newPizza) {
        super(newPizza);
        System.out.println("Adding Fresh Tomato");
    }
    public String getDescription() {
        return tempPizza.getDescription() + ", Fresh Tomato";
    }

    @Override
    public String getIngredients() {
        return null;
    }

    public double getPrice() throws SQLException {
        return tempPizza.getPrice() + .35;
    }
}

