import java.sql.SQLException;

public class Barbeque extends ToppingsDecorator {
    public Barbeque(Pizza newPizza) {
        super(newPizza);
        System.out.println("Adding Barbeque");
    }
    public String getDescription() {
        return tempPizza.getDescription() + ", Barbeque";
    }
    public double getPrice() throws SQLException {
        return tempPizza.getPrice() + .50;
    }
    @Override
    public String getIngredients() {
        return null;
    }
}

