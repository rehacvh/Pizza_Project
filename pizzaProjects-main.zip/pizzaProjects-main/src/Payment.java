import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Payment {
    Database db = Database.getInstance();
    // Attributes
    private Integer id;
    private Integer user_id;
    private Integer order_id;
    private Integer card_id;
    private double total_payment;
    private  String status;
    private String payment_time;

    // Getters and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return user_id;
    }

    public void setUserId(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getOrderId() {
        return order_id;
    }

    public void setOrderId(Integer order_id) {
        this.order_id = order_id;
    }

    public Integer getCardId() {
        return card_id;
    }

    public void setCardId(Integer card_id) {
        this.card_id = card_id;
    }

    public double getTotalPayment() {
        return total_payment;
    }

    public void setTotalPayment(double total_payment) {
        this.total_payment = total_payment;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPaymentTime() {
        return payment_time;
    }

    public void setPaymentTime(String payment_time) {
        this.payment_time = payment_time;
    }

    // Methods
    public void makePayment() throws SQLException {
        // Get date and time
        String now = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        // Make payment
        db.insertOrUpdate("INSERT INTO payment (user_id, order_id, card_id, total_payment, status, payment_time) VALUES (" + this.user_id + ", " + this.order_id + ", " + this.card_id + ", " + this.total_payment + ", '" + this.status + "', '" + now + "')");
    }



}
