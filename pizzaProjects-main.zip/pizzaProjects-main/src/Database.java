import java.sql.*;

public class Database {
    // Use singleton pattern to create only one instance of the database & connection
    private static Database instance = new Database();

    private Connection connection;

    private Database() {
        try {
            // Create a connection to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/pizzastore", "root", "");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    // Get Instance of the database
    public static Database getInstance() {
        return instance;
    }
    // Connect to the database
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/pizzastore";
        String user = "root";
        String password = "";
        // If there is no connection, create one
        if (instance.connection == null) {
            instance.connection = DriverManager.getConnection(url, user, password);
        }
        return instance.connection;
    }

    // Query the database
    public ResultSet query(String query) throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);
        return resultSet;
    }

    // Get the first row of the result set
    public ResultSet getFirstRow(String query) throws SQLException {
        ResultSet resultSet = query(query);
        if (resultSet.next()) {
            return resultSet;
        }
        return null;
    }

    // Insert or update a record in the database
    public static void insertOrUpdate(String query) throws SQLException {
        Connection myConn = Database.getConnection();
        Statement myStmt = myConn.createStatement();
        myStmt.executeUpdate(query);
    }

    // Delete a record from the database
    public static void delete(String query) throws SQLException {
        Connection myConn = Database.getConnection();
        Statement myStmt = myConn.createStatement();
        myStmt.executeUpdate(query);
    }


}
