import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Admin extends User{
    // Use singleton pattern to ensure only one instance of Admin is created
    private static Admin instance = new Admin();

    // Private constructor to prevent instantiation
    private Admin() {

    }
    // Get instance of Admin

    public static Admin getInstance() {
        return instance;
    }

    @Override
    protected void registerUser(String username, String password, String address, String contact_number) throws SQLException {
        // Check if there's already an admin registered
        if(isAdminRegistered()){
            System.out.println("Admin is already registered");
            return;
        }
        // Register the user
        db.insertOrUpdate("INSERT INTO users (username, password, role) VALUES ('" + username + "', '" + password + "', 'Admin')");
        SetId(username);
    }

    // Check to see if there's already an admin registered
    protected boolean isAdminRegistered() throws SQLException {
        ResultSet isAdminRegistered = db.getFirstRow("SELECT * FROM users WHERE role = 'Admin'");
        if (isAdminRegistered == null) {
            return false;
        }
        return true;
    }

    // Add pizza category to the database
    public void addPizzaCategory(String category) throws SQLException {
        db.insertOrUpdate("INSERT INTO pizza_categories (category_name) VALUES ('" + category + "')");
    }

    // Edit pizza category in the database
    public void editPizzaCategory(String oldCategory, String newCategory) throws SQLException {
        db.insertOrUpdate("UPDATE pizza_categories SET category_name = '" + newCategory + "' WHERE category_name = '" + oldCategory + "'");
    }

    // Delete pizza category from the database
    public void deletePizzaCategory(String category) throws SQLException {
        db.delete("DELETE FROM pizza_categories WHERE category_name = '" + category + "'");
    }

    // Check availability of pizza based on Enum value in availability column
    public boolean isPizzaAvailable(String pizzaName) throws SQLException {
        String availability = db.getFirstRow("SELECT availability FROM pizzas WHERE pizza_name = '" + pizzaName + "'").getString("availability");
        if(availability.equals("Available")){
            return true;
        }else{
            return false;
        }
    }

    // Set pizza availability in the database
    public void setPizzaAvailability(String pizzaName, String availability) throws SQLException {
        db.insertOrUpdate("UPDATE pizzas SET availability = '" + availability + "' WHERE pizza_name = '" + pizzaName + "'");
    }

    // Assign Delivery Agent to a pizza order
    public void assignDeliveryAgent(Integer OrderId, Integer DeliveryAgentId) throws SQLException {
        db.insertOrUpdate("UPDATE pizza_orders SET delivery_id = " + DeliveryAgentId + " WHERE id = " + OrderId);
    }

    // Change the status of a pizza order
    public void changeOrderStatus(Integer OrderId, String status) throws SQLException {
        db.insertOrUpdate("UPDATE pizza_orders SET status = '" + status + "' WHERE id = " + OrderId);
    }

    // Change the price of a pizza
    public void changePizzaPrice(String pizzaName, Double price) throws SQLException {
        db.insertOrUpdate("UPDATE pizzas SET price = " + price + " WHERE pizza_name = '" + pizzaName + "'");
    }

    // Change user details

    // Change user's address
    public void changeUserAddress(Integer userId, String address) throws SQLException {
        db.insertOrUpdate("UPDATE users SET address = '" + address + "' WHERE id = " + userId);
    }

    // Change user's contact number
    public void changeUserContactNumber(Integer userId, String contactNumber) throws SQLException {
        db.insertOrUpdate("UPDATE users SET contact_number = '" + contactNumber + "' WHERE id = " + userId);
    }

    // Change user's username
    public void changeUserUsername(Integer userId, String username) throws SQLException {
        db.insertOrUpdate("UPDATE users SET username = '" + username + "' WHERE id = " + userId);
    }

    // Change delivery agent availability in the delivery_availability table
    public void changeDeliveryAgentAvailability(Integer deliveryAgentId, boolean availability) throws SQLException {
        db.insertOrUpdate("UPDATE delivery_availability SET availability = '" + availability + "' WHERE delivery_id = " + deliveryAgentId);
    }

    // Get all payments done by a user
    public ArrayList<Payment> getUserPayments(Integer userId) throws SQLException {
        ResultSet result = db.query("SELECT * FROM payments WHERE user_id = " + userId);
        ArrayList<Payment> payments = new ArrayList<>();
        while(result.next()){
            Payment payment = new Payment();
            payment.setId(result.getInt("id"));
            payment.setUserId(result.getInt("user_id"));
            payment.setTotalPayment(result.getDouble("amount"));
            payment.setStatus(result.getString("payment_method"));
            payment.setPaymentTime(result.getString("payment_time"));
            payments.add(payment);
        }
        return payments;
    }

    // Get all orders made by a user
    public ArrayList<Order> getUserOrders(Integer userId) throws SQLException {
        ResultSet result = db.query("SELECT * FROM pizza_orders WHERE user_id = " + userId);
        ArrayList<Order> orders = new ArrayList<>();
        while(result.next()){
            Order order = new Order();
            order.setId(result.getInt("id"));
            order.setUserId(result.getInt("user_id"));
            order.setDeliveryId(result.getInt("delivery_id"));
            order.setTotalCost(result.getDouble("total_price"));
            order.setOrderTime(result.getString("created_at"));
            order.setStatus(result.getString("status"));
            order.setPizzasCount(result.getInt("pizzas_count"));
            order.setPaymentMethod(result.getString("payment_method"));
            orders.add(order);
        }
        return orders;
    }

    // Get all orders
    public ArrayList<Order> getAllOrders() throws SQLException {
        ResultSet result = db.query("SELECT * FROM pizza_orders");
        ArrayList<Order> orders = new ArrayList<>();
        while(result.next()){
            Order order = new Order();
            order.setId(result.getInt("id"));
            order.setUserId(result.getInt("user_id"));
            order.setDeliveryId(result.getInt("delivery_id"));
            order.setTotalCost(result.getDouble("total_price"));
            order.setOrderTime(result.getString("created_at"));
            order.setStatus(result.getString("status"));
            orders.add(order);
        }
        return orders;
    }

    // Confirm an order
    public void confirmOrder(Integer orderId) throws SQLException {
        db.insertOrUpdate("UPDATE pizza_orders SET status = 'Confirmed' WHERE id = " + orderId);
    }

    // Cancel an order
    public void cancelOrder(Integer orderId) throws SQLException {
        db.insertOrUpdate("UPDATE pizza_orders SET status = 'Cancelled' WHERE id = " + orderId);
    }

    // View an order
    public Order viewOrder(Integer orderId) throws SQLException {
        ResultSet result = db.query("SELECT * FROM pizza_orders WHERE id = " + orderId);
        Order order = new Order();
        while(result.next()){
            order.setId(result.getInt("id"));
            order.setUserId(result.getInt("user_id"));
            order.setDeliveryId(result.getInt("delivery_id"));
            order.setTotalCost(result.getDouble("total_price"));
            order.setOrderTime(result.getString("created_at"));
            order.setStatus(result.getString("status"));
        }
        return order;
    }

    // Get all number of pizzas sold
    public Integer getPizzasSold() throws SQLException {
        ResultSet result = db.query("SELECT SUM(pizzas_count) AS pizzas_sold FROM orders");
        Integer pizzasSold = 0;
        while(result.next()){
            pizzasSold = result.getInt("pizzas_sold");
        }
        return pizzasSold;
    }




}
