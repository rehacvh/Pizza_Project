import java.sql.SQLException;

abstract class ToppingsDecorator implements Pizza {
    protected Pizza tempPizza;
    public ToppingsDecorator(Pizza newPizza) {
        tempPizza = newPizza;
    }
    public String getDescription() {
        return tempPizza.getDescription();
    }
    public double getPrice() throws SQLException {
        return tempPizza.getPrice();
    }
}

