import java.sql.SQLException;

public class MargheritaPizza implements Pizza {
    private String description;
    Database db = Database.getInstance();
    public MargheritaPizza() {
        description = "Margherita";
    }
    public double getPrice() throws SQLException {
        // Get the cost of the pizza from the database
        return db.getFirstRow("SELECT price FROM pizzas WHERE pizza_name = 'Pepperoni Pizza'").getDouble("price");
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getIngredients() {
        return null;
    }

}
