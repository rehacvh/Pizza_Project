import java.sql.SQLException;

public class HawaiianPizza implements Pizza {
    Database db = Database.getInstance();
    private String description;
    public HawaiianPizza() {
        description = "Hawaiian Pizza";
    }
    public double getCost() throws SQLException {
        // Get the cost of the pizza from the database
        return db.getFirstRow("SELECT price FROM pizzas WHERE pizza_name = 'Hawaiian Pizza'").getDouble("price");
    }

    @Override
    public String getDescription() {
        return null;
    }

    @Override
    public String getIngredients() {
        return null;
    }

    @Override
    public double getPrice() {
        return 0;
    }
}
