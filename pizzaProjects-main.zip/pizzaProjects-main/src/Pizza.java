import java.sql.SQLException;

public interface Pizza {
//    Implement Pizza Interface
    String getIngredients () throws SQLException;

    double getPrice() throws SQLException;

    String getDescription();
}
