import java.sql.SQLException;

public class MeatLoversPizza implements Pizza {
    private String description;
    Database db = Database.getInstance();
    public MeatLoversPizza() {
        description = "Meat Lovers Pizza";
    }
    public double getPrice() throws SQLException {
        // Get the cost of the pizza from the database
        return db.getFirstRow("SELECT price FROM pizzas WHERE pizza_name = 'Meat Lovers Pizza'").getDouble("price");
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getIngredients() {
        return null;
    }

}
