import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class User {
    // DB Instance
    Database db = Database.getInstance();

    // User attributes
    private int id;
    private String username;
    private String role;
    boolean loggedIn = false;

    private String address;

    private String contact_number;

    // Login function
    public void login(String username, String password) throws SQLException {
        // Check if the user is already logged in
        if (isLoggedIn()) {
            System.out.println("User is already logged in");
            return;
        }
        // Check if the user is already registered
        if (!isRegistered(username)) {
            System.out.println("User is not registered");
            return;
        }
        // Check if the password is correct
        if (!isPasswordCorrect(username, password)) {
            System.out.println("Password is incorrect");
            return;
        }
        // Set the user as logged in
        setLoggedIn(true);
        setUsername(username);
        setRole(username);
        SetId(username);
        setAddressFromDB(username);
        setContactNumberFromDB(username);
        System.out.println("User logged in");
    }



    // Register function
    public void register(String username, String password, String address, String contact_number) throws SQLException {
        // Check if the user is already logged in
        if (isLoggedIn()) {
            System.out.println("User is already logged in");
            return;
        }
        // Check if the user is already registered
        if (isRegistered(username)) {
            System.out.println("User is already registered");
            return;
        }
        // Register the user
        try {
            registerUser(username, password, address, contact_number );
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        System.out.println("User registered");
    }
    // Logout function
    public void logout() {
        // Check if the user is already logged in
        if (!isLoggedIn()) {
            System.out.println("User is not logged in");
            return;
        }
        // Set the user as logged out
        setLoggedIn(false);
        System.out.println("User logged out");
    }
    // Check if the user is already logged in
    public boolean isLoggedIn() {
        return loggedIn;
    }
    // Check if the user is already registered
    protected boolean isRegistered(String username) throws SQLException {
        ResultSet userRegistered = db.getFirstRow("SELECT * FROM users WHERE username = '" + username + "'");
        if (userRegistered == null) {
            return false;
        }
        return true;
    }
    // Check if the password is correct
    protected boolean isPasswordCorrect(String username, String password) throws SQLException {
        ResultSet isPasswordCorrect = db.getFirstRow("SELECT * FROM users WHERE username = '" + username + "' AND password = '" + password + "'");
        if(isPasswordCorrect == null) {
            return false;
        }
        return true;
    }
    // Register the user
    protected void registerUser(String username, String password, String address, String contact_number) throws SQLException {
        db.insertOrUpdate("INSERT INTO users (username, password, address, contact_number, role) VALUES ('" + username + "', '" + password + "', '"+ address +"', '"+ contact_number +"', 'user')");
        // Set user attributes
        setUsername(username);
        this.role = "user";
        SetId(username);
    }

    void SetId(String username) {
        try {
            ResultSet rs = db.query("SELECT id FROM users WHERE username = '" + username + "'");
            if (rs.next()) {
                this.id = rs.getInt("id");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Change password
    public void changePassword(String oldPassword, String newPassword) throws SQLException {
        // Check if the user is already logged in
        if (!isLoggedIn()) {
            System.out.println("User is not logged in");
            return;
        }
        // Check if the old password is correct
        if (!isPasswordCorrect(username, oldPassword)) {
            System.out.println("Old password is incorrect");
            return;
        }
        // Change the password
        db.insertOrUpdate("UPDATE users SET password = '" + newPassword + "' WHERE username = '" + username + "'");
        System.out.println("Password changed");
    }

    protected void setRole(String username) throws SQLException {
        if (this.role == null) {
            this.role = db.getFirstRow("SELECT role FROM users WHERE username = '" + username + "'").getString(1);
        }
    }

    protected void setUsername(String username) {
        if(username != null) {
            this.username = username;
        }
    }

    // Set the user as logged in
    protected void setLoggedIn(boolean status) {
        loggedIn = status;
    }

    // Get the user's role
    public String getRole() {
        return role;
    }

    private void setContactNumberFromDB(String username) throws SQLException {
        String contactNumber = db.getFirstRow("SELECT contact_number FROM users WHERE username = '" + username + "'").getString("contact_number");
        this.contact_number = contactNumber;
    }

    private void setAddressFromDB(String username) throws SQLException {
        String address = db.getFirstRow("SELECT address FROM users WHERE username = '" + username + "'").getString("address");
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public String getContactNumber() {
        return contact_number;
    }

    // View Pizza Categories
    public ArrayList viewPizzaCategories() throws SQLException {
        // Check if the user is logged in
        if (!isLoggedIn()) {
            System.out.println("User is not logged in");
            return null;
        }
        // Get the pizza categories
        ResultSet categories = db.query("SELECT * FROM pizza_categories");
        // Create an array list to store the categories
        ArrayList<String> categoriesList = new ArrayList<String>();
        // Loop through the categories and add them to the array list
        while (categories.next()) {
            categoriesList.add(categories.getString(2));
        }
        return categoriesList;
    }

    // Get the user's id
    public int getId() {
        return id;
    }

    // Check if user has a card in the database
    public boolean hasCard() throws SQLException {
        ResultSet card = db.getFirstRow("SELECT * FROM cards WHERE user_id = '" + getId() + "'");
        if (card == null) {
            return false;
        }
        return true;
    }

    public void updateAddress(String address) throws SQLException {
        db.insertOrUpdate("UPDATE users SET address = '" + address + "' WHERE user_id = '" + getId() + "'");
        this.address = address;
    }

    public void updateContactNumber(String contact_number) throws SQLException {
        db.insertOrUpdate("UPDATE users SET contact_number = '" + contact_number + "' WHERE user_id = '" + getId() + "'");
        this.contact_number = contact_number;
    }

    // return all the pizzas in the database in a key value pair of pizza name and price
    public HashMap<String, Double> viewPizzas() throws SQLException {
        // Check if the user is logged in
        if (!isLoggedIn()) {
            System.out.println("User is not logged in");
            return null;
        }
        // Get the pizzas that are available
        ResultSet pizzas = db.query("SELECT * FROM pizzas WHERE availability = 'Available'");
        // Create a hash map to store the pizzas
        HashMap<String, Double> pizzasList = new HashMap<String, Double>();
        // Loop through the pizzas and add them to the hash map
        while (pizzas.next()) {
            pizzasList.put(pizzas.getString("pizza_name"), pizzas.getDouble("price"));
        }
        return pizzasList;
    }

    // return all the pizzas in the database in a key value pair of pizza name and price in a specific category
    public HashMap<String, Double> viewPizzas(String category) throws SQLException {
        // Check if the user is logged in
        if (!isLoggedIn()) {
            System.out.println("User is not logged in");
            return null;
        }
        // Get the category id
        Integer category_id = db.getFirstRow("SELECT id FROM pizza_categories WHERE category_name = '" + category + "'").getInt("id");
        // Get the pizzas that are available
        ResultSet pizzas = db.query("SELECT * FROM pizzas WHERE category_id = '" + category_id + "' AND availability = 'Available'");
        // Create a hash map to store the pizzas
        HashMap<String, Double> pizzasList = new HashMap<String, Double>();
        // Loop through the pizzas and add them to the hash map
        while (pizzas.next()) {
            pizzasList.put(pizzas.getString("pizza_name"), pizzas.getDouble("price"));
        }
        return pizzasList;
    }


}
