import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DeliveryAgent extends User{
    @Override
    protected void registerUser(String username, String password, String address, String contact_number) throws SQLException {
        // Register the user
        db.insertOrUpdate("INSERT INTO users (username, password, address, contact_number, role) VALUES ('" + username + "', '" + password + "', '"+ address +"', '"+ contact_number +"', 'Delivery')");
        SetId(username);
    }

    // Get Delivery Agent's assigned orders that their status is not delivered
    public ArrayList getAssignedOrders() throws SQLException {
       ResultSet result =  db.query("SELECT * FROM pizza_orders WHERE delivery_id = " + getId() + " AND status != 'Delivered'");
         ArrayList<Order> orders = new ArrayList<>();
            while (result.next()) {
                Order order = new Order();
                order.setId(result.getInt("id"));
                order.setUserId(result.getInt("user_id"));
                order.setDeliveryId(result.getInt("delivery_id"));
                order.setOrderDetails(result.getString("order_details"));
                order.setStatus(result.getString("status"));
                order.setTotalCost(result.getDouble("total_cost"));
                orders.add(order);
            }
        return orders;
    }

    // Change the availability of the delivery agent
    public void changeAvailability(Boolean availability) throws SQLException {
        // Check if the user is already logged in
        if (!isLoggedIn()) {
            System.out.println("User is not logged in");
            return;
        }
        // Check if the user is a delivery agent
        if (!isDeliveryAgent()) {
            System.out.println("User is not a delivery agent");
            return;
        }
        // Change the availability of the delivery agent in delivery_availability table
        db.insertOrUpdate("UPDATE delivery_availability SET availability = " + availability + " WHERE delivery_id = " + getId());

    }

    // Check if the delivery agent is available from delivery_availability table
    private boolean isAvailable() {
        try {
            ResultSet rs = db.query("SELECT available FROM delivery_availability WHERE delivery_id = " + getId());
            if (rs.next()) {
                return rs.getBoolean("availability");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return false;
    }

    private boolean isDeliveryAgent() {
        return getRole().equals("Delivery");
    }


}
